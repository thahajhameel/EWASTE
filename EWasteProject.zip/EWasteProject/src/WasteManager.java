import java.util.ArrayList;
import java.util.List;
import java.io.*;

// This class does all the "real work": adding items, listing them,
// searching, updating status, and deciding which center an item goes to.
public class WasteManager {

    // In-memory storage: a list that holds all EWasteItem objects
    private List<EWasteItem> items = new ArrayList<>();
    private int nextId = 1; // auto-incrementing ID generator

    private static final String FILE_NAME = "ewaste_data.txt";

    // ---- Add a new item ----
    public EWasteItem addItem(String itemType, String ownerName, String address, double weightKg) {
        EWasteItem item = new EWasteItem(nextId, itemType, ownerName, address, weightKg);
        items.add(item);
        nextId++;
        return item;
    }

    // ---- List all items ----
    public void listAll() {
        if (items.isEmpty()) {
            System.out.println("No e-waste records found.");
            return;
        }
        for (EWasteItem item : items) {
            System.out.println(item);
        }
    }

    // ---- Search by ID ----
    public EWasteItem findById(int id) {
        for (EWasteItem item : items) {
            if (item.getId() == id) return item;
        }
        return null; // not found
    }

    // ---- Search by status (Pending / Collected / Relocated) ----
    public void listByStatus(String status) {
        boolean found = false;
        for (EWasteItem item : items) {
            if (item.getStatus().equalsIgnoreCase(status)) {
                System.out.println(item);
                found = true;
            }
        }
        if (!found) System.out.println("No items with status: " + status);
    }

    // ---- Mark an item as Collected ----
    public boolean markCollected(int id) {
        EWasteItem item = findById(id);
        if (item == null) return false;
        item.setStatus("Collected");
        return true;
    }

    // ---- Relocation logic: decides which center an item goes to ----
    // This is the "smart" part of the project — a simple rule-based decision.
    public boolean relocateItem(int id) {
        EWasteItem item = findById(id);
        if (item == null) return false;

        if (!item.getStatus().equals("Collected")) {
            System.out.println("Item must be marked Collected before it can be relocated.");
            return false;
        }

        String center;
        switch (item.getItemType().toLowerCase()) {
            case "battery":
                center = "Hazardous Waste Center - Zone A";
                break;
            case "mobile":
            case "laptop":
            case "computer":
                center = "Electronics Recycling Plant - Zone B";
                break;
            case "metal scrap":
            case "metal":
                center = "Metal Recovery Unit - Zone C";
                break;
            case "plastic":
                center = "Plastic Recycling Facility - Zone D";
                break;
            default:
                center = "General E-Waste Sorting Center";
        }

        item.setAssignedCenter(center);
        item.setStatus("Relocated");
        return true;
    }

    // ---- Save all records to a text file (simple persistence) ----
    public void saveToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_NAME))) {
            for (EWasteItem item : items) {
                // Save as comma-separated values (CSV-style)
                writer.println(item.getId() + "," + item.getItemType() + "," +
                        item.getOwnerName() + "," + item.getAddress() + "," +
                        item.getWeightKg() + "," + item.getStatus() + "," +
                        item.getAssignedCenter());
            }
            System.out.println("Data saved to " + FILE_NAME);
        } catch (IOException e) {
            System.out.println("Error saving file: " + e.getMessage());
        }
    }

    // ---- Load records from the text file on startup ----
    public void loadFromFile() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return; // nothing to load yet

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int maxId = 0;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length < 7) continue;

                int id = Integer.parseInt(parts[0]);
                EWasteItem item = new EWasteItem(id, parts[1], parts[2], parts[3], Double.parseDouble(parts[4]));
                item.setStatus(parts[5]);
                item.setAssignedCenter(parts[6]);
                items.add(item);

                if (id > maxId) maxId = id;
            }
            nextId = maxId + 1; // continue ID numbering from where we left off
            System.out.println("Loaded " + items.size() + " record(s) from file.");
        } catch (IOException e) {
            System.out.println("Error loading file: " + e.getMessage());
        }
    }
}