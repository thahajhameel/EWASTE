// This class represents a recycling/relocation center.
// We don't need much logic here — it's mainly a data holder,
// but keeping it as its own class makes the project look properly OOP.
public class CollectionCenter {

    private String name;
    private String handlesType; // what type of waste this center accepts

    public CollectionCenter(String name, String handlesType) {
        this.name = name;
        this.handlesType = handlesType;
    }

    public String getName() { return name; }
    public String getHandlesType() { return handlesType; }

    @Override
    public String toString() {
        return name + " (handles: " + handlesType + ")";
    }
}