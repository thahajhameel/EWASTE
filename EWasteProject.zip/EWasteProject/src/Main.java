import java.util.Scanner;

// This is the entry point of the program — the console menu.
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        WasteManager manager = new WasteManager();

        manager.loadFromFile(); // load any previously saved data

        boolean running = true;
        while (running) {
            printMenu();
            System.out.print("Enter choice: ");
            int choice;
            try {
                choice = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Enter a number.\n");
                continue;
            }

            switch (choice) {
                case 1: // Add new item
                    System.out.print("Item type (Battery/Mobile/Laptop/Metal Scrap/Plastic/Other): ");
                    String type = sc.nextLine();
                    System.out.print("Owner name: ");
                    String owner = sc.nextLine();
                    System.out.print("Address: ");
                    String address = sc.nextLine();
                    System.out.print("Weight (kg): ");
                    double weight;
                    try {
                        weight = Double.parseDouble(sc.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid weight. Cancelled.\n");
                        break;
                    }
                    EWasteItem newItem = manager.addItem(type, owner, address, weight);
                    System.out.println("Added: " + newItem + "\n");
                    break;

                case 2: // List all
                    System.out.println("---- All E-Waste Records ----");
                    manager.listAll();
                    System.out.println();
                    break;

                case 3: // Mark collected
                    System.out.print("Enter item ID to mark as Collected: ");
                    int collectId = readInt(sc);
                    if (manager.markCollected(collectId)) {
                        System.out.println("Item " + collectId + " marked as Collected.\n");
                    } else {
                        System.out.println("Item not found.\n");
                    }
                    break;

                case 4: // Relocate
                    System.out.print("Enter item ID to relocate: ");
                    int relocateId = readInt(sc);
                    if (manager.relocateItem(relocateId)) {
                        System.out.println("Item " + relocateId + " relocated successfully.\n");
                    } else {
                        System.out.println("Could not relocate item (check ID/status).\n");
                    }
                    break;

                case 5: // Search by ID
                    System.out.print("Enter item ID to search: ");
                    int searchId = readInt(sc);
                    EWasteItem found = manager.findById(searchId);
                    System.out.println(found != null ? found : "Item not found.");
                    System.out.println();
                    break;

                case 6: // Search by status
                    System.out.print("Enter status (Pending/Collected/Relocated): ");
                    String status = sc.nextLine();
                    manager.listByStatus(status);
                    System.out.println();
                    break;

                case 7: // Save
                    manager.saveToFile();
                    System.out.println();
                    break;

                case 0: // Exit
                    manager.saveToFile(); // auto-save on exit
                    System.out.println("Goodbye!");
                    running = false;
                    break;

                default:
                    System.out.println("Invalid choice.\n");
            }
        }
        sc.close();
    }

    // Helper to safely read an integer from Scanner
    private static int readInt(Scanner sc) {
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1; // invalid ID, will simply not be found
        }
    }

    private static void printMenu() {
        System.out.println("===== E-WASTE COLLECTOR & RELOCATOR =====");
        System.out.println("1. Add new e-waste item");
        System.out.println("2. View all items");
        System.out.println("3. Mark item as Collected");
        System.out.println("4. Relocate item to recycling center");
        System.out.println("5. Search by ID");
        System.out.println("6. Search by status");
        System.out.println("7. Save data to file");
        System.out.println("0. Exit");
    }
}