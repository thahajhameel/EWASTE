// This class represents ONE piece of e-waste in the system.
// Think of it as a "record" or "row" — it just holds data and has getters/setters.
public class EWasteItem {

    // ---- Fields (the data each item holds) ----
    private int id;
    private String itemType;     // e.g. "Battery", "Laptop", "Mobile", "Metal Scrap"
    private String ownerName;
    private String address;
    private double weightKg;
    private String status;       // "Pending", "Collected", "Relocated"
    private String assignedCenter; // filled in once relocation logic runs

    // ---- Constructor: runs when we create a new EWasteItem ----
    public EWasteItem(int id, String itemType, String ownerName, String address, double weightKg) {
        this.id = id;
        this.itemType = itemType;
        this.ownerName = ownerName;
        this.address = address;
        this.weightKg = weightKg;
        this.status = "Pending";       // every new item starts as Pending
        this.assignedCenter = "Not Assigned";
    }

    // ---- Getters (used to read the data) ----
    public int getId() { return id; }
    public String getItemType() { return itemType; }
    public String getOwnerName() { return ownerName; }
    public String getAddress() { return address; }
    public double getWeightKg() { return weightKg; }
    public String getStatus() { return status; }
    public String getAssignedCenter() { return assignedCenter; }

    // ---- Setters (used to update the data) ----
    public void setStatus(String status) { this.status = status; }
    public void setAssignedCenter(String assignedCenter) { this.assignedCenter = assignedCenter; }

    // ---- toString: defines how this object prints in console ----
    @Override
    public String toString() {
        return String.format("ID:%-4d | Type:%-12s | Owner:%-10s | Weight:%-6.2fkg | Status:%-10s | Center:%s",
                id, itemType, ownerName, weightKg, status, assignedCenter);
    }
}